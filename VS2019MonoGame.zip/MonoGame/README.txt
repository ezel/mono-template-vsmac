The MonoGame Folder should go under the following location.

C:\Users\<user id>\Documents\Visual Studio 2019\Templates\ProjectTemplates\Visual C#\

The result will be:

C:\Users\<user id>\Documents\Visual Studio 2019\Templates\ProjectTemplates\Visual C#\MonoGame\